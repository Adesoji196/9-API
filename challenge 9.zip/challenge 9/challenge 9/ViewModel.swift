//
//  ViewModel.swift
//  challenge 9
//
//  Created by Turma02-1 on 22/10/26.
//

import Foundation
@Observable
class ViewModel {
    var personagens: [HaPo] = []
    
    private let service = Service ()
    
    func fetch () async {
        let url = "https://hp-api.onrender.com/api/characters/house/gryffindor"
        do {
            personagens = try await service.fetchPersonagens(url: url)
            print(personagens.count)
        } catch {
            print(error.localizedDescription)
        }
    }
}
