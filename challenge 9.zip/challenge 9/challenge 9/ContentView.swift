//
//  ContentView.swift
//  challenge 9
//
//  Created by Turma02-1 on 22/10/26.
//

import SwiftUI

struct ContentView: View {
    
    @State private var viewModel = ViewModel()
    
    var body: some View {
        ZStack {
            Color.red
            VStack {
                ScrollView {
                    ForEach(viewModel.personagens) { e in
                        HStack {
                            AsyncImage(url: URL(string: e.image ?? "")) { image in
                                image
                                    .resizable()
                                    .frame(width: 50, height: 50)
                            } placeholder: {
                                ProgressView()
                            }
                            
                            Text(e.name ?? "default")
                        }
                    }
                }
            }
            .task {
                await viewModel.fetch()
            }
        }
    }
}

#Preview {
    ContentView()
}
