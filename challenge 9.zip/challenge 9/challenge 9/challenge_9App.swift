//
//  challenge_9App.swift
//  challenge 9
//
//  Created by Turma02-1 on 22/10/26.
//

import SwiftUI

@main
struct challenge_9App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
